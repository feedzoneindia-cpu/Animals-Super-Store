import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Button from '../components/common/Button.jsx';
import FormInput, { FormError } from '../components/common/FormInput.jsx';
import Spinner from '../components/common/Spinner.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import GoogleSignInButton from '../components/auth/GoogleSignInButton.jsx';
import useSEO from '../hooks/useSEO.js';

const MAIL = (
  <svg className="h-[18px] w-[18px]" fill="none" viewBox="0 0 24 24" strokeWidth="1.6" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" /></svg>
);
const LOCK = (
  <svg className="h-[18px] w-[18px]" fill="none" viewBox="0 0 24 24" strokeWidth="1.6" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" /></svg>
);

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useSEO({ title: 'Log In', noindex: true, description: 'Log in to your Animal Super Store account.' });

  const [values, setValues] = useState({ email: '', password: '' });
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);

  const setField = (field) => (event) => {
    setValues((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const validate = () => {
    const errors = {};
    if (!values.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
    if (!values.password) {
      errors.password = 'Password is required';
    }
    return errors;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setFormError('');
    const errors = validate();
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setLoading(true);
    try {
      await login(values);
      navigate(location.state?.from ?? '/', { replace: true });
    } catch (err) {
      setFormError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      className="relative isolate overflow-hidden bg-brand-50 bg-cover bg-[70%_center] bg-no-repeat lg:bg-left"
      style={{ backgroundImage: "url('/auth-bg.jpg')" }}
    >
      {/* Soft white fade on the right so the card stays readable over the photo */}
      <div className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-l from-white/50 via-white/10 to-transparent" aria-hidden="true" />

      <div className="mx-auto grid min-h-[calc(100vh-16rem)] max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-2 lg:gap-6 lg:py-16">
        {/* Left: welcome copy + pets illustration (desktop only) */}
        <div className="relative hidden min-h-[28rem] self-stretch lg:block">
           <Link to="/" className="flex h-20 w-25 items-center justify-center mx-auto" aria-label="Animal Super Store home">
              <img src="/animal-super-store-logo.png" alt="logo" />
            </Link>
          <div className="pt-10">
            <h1 className="text-4xl font-extrabold tracking-tight text-brand-700 xl:text-5xl">Welcome Back</h1>
            <p className="mt-4 max-w-xs text-lg leading-relaxed text-gray-700">
              Sign in to continue your journey with happy and healthy pets.
            </p>
          </div>
        </div>

        {/* Right: login card */}
        <div className="mx-auto w-full max-w-md">
          <div className="rounded-3xl border border-white/60 bg-white/95 p-6 shadow-2xl shadow-brand-900/10 backdrop-blur-md sm:p-8">
            <h2 className="mt-3 text-2xl font-extrabold tracking-tight text-brand-700">Login to Your Account</h2>
            <p className="mt-1 text-sm text-gray-600">Welcome back! Please enter your details.</p>

            {loading && (
              <div className="mt-4 flex items-center gap-2 text-sm text-gray-500" aria-live="polite">
                <Spinner size="sm" label="Signing in" /> Signing you in…
              </div>
            )}
            <div className="mt-5">
              <FormError message={formError} />
            </div>
            <form onSubmit={handleSubmit} noValidate className={formError ? 'mt-4' : ''}>
              <div className="space-y-5">
                <FormInput
                  label="Email"
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  placeholder="you@example.com"
                  icon={MAIL}
                  value={values.email}
                  onChange={setField('email')}
                  error={fieldErrors.email}
                />
                <FormInput
                  label="Password"
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  placeholder="Your password"
                  icon={LOCK}
                  value={values.password}
                  onChange={setField('password')}
                  error={fieldErrors.password}
                />
                <div className="-mt-3 text-right">
                  <Link to="/forgot-password" className="text-xs font-semibold text-brand-500 hover:text-brand-700">
                    Forgot password?
                  </Link>
                </div>
              </div>
              <Button type="submit" size="lg" className="mt-5 w-full" loading={loading} disabled={loading}>
                Login
              </Button>
            </form>

            <div className="my-5 flex items-center gap-3 text-xs text-gray-500" aria-hidden="true">
              <span className="h-px flex-1 bg-brand-200" />
              or continue with
              <span className="h-px flex-1 bg-brand-200" />
            </div>

            <GoogleSignInButton
              onSuccess={() => navigate(location.state?.from ?? '/', { replace: true })}
              onError={setFormError}
            />
          </div>

          <p className="mt-6 text-center text-sm font-medium text-gray-700 drop-shadow-sm">
            Don&apos;t have an account?{' '}
            <Link to="/register" className="font-semibold text-brand-700 underline underline-offset-2 hover:text-brand-800">
              Register here
            </Link>
          </p>
        </div>
      </div>
    </section>
  );
}
